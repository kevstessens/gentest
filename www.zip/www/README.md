BarcodeDemo
===========

A PhoneGap app demoing the [BarcodeScanner Plugin](http://github.com/wildabeast/BarcodeScanner).

Includes config.xml file for [PhoneGap Build](https://build.phonegap.com).
