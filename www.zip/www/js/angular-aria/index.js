require('./angular-aria');
module.exports = 'ngAria';
