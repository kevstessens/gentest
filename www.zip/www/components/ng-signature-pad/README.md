# ng-signature-pad

> An AngularJS directive for signature_pad

## Usage

See [demo](http://plnkr.co/edit/mWA2Wt?p=preview).

## Author

Javier Martínez Fernández released under the MIT license.
